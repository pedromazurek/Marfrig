USE [BancoTESTE]
GO

INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 1')

	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 2')

	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 3')

GO

	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 4')

GO

	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 5')

GO

	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 6')

GO
	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 7')

GO
	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 8')

GO
	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 9')

GO
	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 10')

GO
	INSERT INTO [dbo].[MF_Pecuarista]
    ([Nome])
VALUES
    ('pecuarista 11')
GO

INSERT INTO [dbo].[MF_Animal]
           ([Descricao]
           ,[Preco])
     VALUES
           ('Vaca'
           ,2000)

INSERT INTO [dbo].[MF_Animal]
           ([Descricao]
           ,[Preco])
     VALUES
           ('Boi'
           ,3500)

		   INSERT INTO [dbo].[MF_Animal]
           ([Descricao]
           ,[Preco])
     VALUES
           ('Angus'
           ,1000)
GO
INSERT INTO [dbo].[MF_Animal]
           ([Descricao]
           ,[Preco])
     VALUES
           ('Nelore'
           ,3500)

