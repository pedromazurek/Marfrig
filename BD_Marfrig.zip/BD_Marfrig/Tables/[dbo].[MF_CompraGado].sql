USE BancoTESTE
GO


/****** Object:  Table [dbo].[MF_CompraGado]    Script Date: 27/04/2022 13:21:15 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO
CREATE TABLE [dbo].[MF_CompraGado](
	[Id] [int] IDENTITY NOT NULL,
	[IdPecuarista] [int] NOT NULL,
	[DataEntrega] [datetime] NOT NULL,
 CONSTRAINT [PK_MF_CompraGado] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[MF_CompraGado]  WITH CHECK ADD  CONSTRAINT [FK_MF_CompraGado_MF_Pecuarista] FOREIGN KEY([IdPecuarista])
REFERENCES [dbo].[MF_Pecuarista] ([Id])
GO

ALTER TABLE [dbo].[MF_CompraGado] CHECK CONSTRAINT [FK_MF_CompraGado_MF_Pecuarista]
GO


