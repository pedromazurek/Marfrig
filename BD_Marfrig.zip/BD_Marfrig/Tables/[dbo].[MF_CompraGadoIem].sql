USE BancoTESTE
GO


/****** Object:  Table [dbo].[MF_CompraGadoIem]    Script Date: 27/04/2022 13:21:22 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MF_CompraGadoIem](
	[Id] [int] identity NOT NULL,
	[IdCompraGado] [int] NOT NULL,
	[IdAnimal] [int] NOT NULL,
	[Quantidade] [int] NOT NULL,
 CONSTRAINT [PK_MF_CompraGadoIem] PRIMARY KEY CLUSTERED 
(
	[Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[MF_CompraGadoIem]  WITH CHECK ADD  CONSTRAINT [FK_MF_CompraGado_CompraGadoIem] FOREIGN KEY([IdCompraGado])
REFERENCES [dbo].[MF_CompraGado] ([Id])
GO

ALTER TABLE [dbo].[MF_CompraGadoIem] CHECK CONSTRAINT [FK_MF_CompraGado_CompraGadoIem]
GO

ALTER TABLE [dbo].[MF_CompraGadoIem]  WITH CHECK ADD  CONSTRAINT [FK_MF_CompraGadoIem_MF_Animal] FOREIGN KEY([IdAnimal])
REFERENCES [dbo].[MF_Animal] ([Id])
GO

ALTER TABLE [dbo].[MF_CompraGadoIem] CHECK CONSTRAINT [FK_MF_CompraGadoIem_MF_Animal]
GO


