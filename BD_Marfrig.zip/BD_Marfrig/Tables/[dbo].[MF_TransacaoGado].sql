USE BancoTESTE
GO


/****** Object:  Table [dbo].[MF_TransacaoGado]   Script Date: 27/04/2022 13:21:10 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO

CREATE TABLE [dbo].[MF_TransacaoGado](
	[Seql_Id] [int] identity NOT NULL,
	[Seql_IdPecuarista][int] NOT NULL,
	[Seql_IdCompraGado][int] NOT NULL,
	[Dat_Entrega][datetime] NOT NULL,
	[Seql_IdAnimal][int] NOT NULL,
	[Ind_Quantidade] [int] NOT NULL,
	[Vlr_CompraTotal] [decimal](12, 2) NOT NULL,
	[Ind_Impresso][int] DEFAULT 0 NOT NULL,
	[Dat_Compra] [datetime] NOT NULL
 CONSTRAINT [PK_MF_TransacaoGado] PRIMARY KEY CLUSTERED 
(
	[Seql_Id] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
GO


ALTER TABLE [dbo].[MF_TransacaoGado]  WITH CHECK ADD CONSTRAINT [FK_MF_TransacaoGado_MF_Pecuarista] FOREIGN KEY([Seql_IdPecuarista])
REFERENCES [dbo].[MF_Pecuarista] ([Id])
GO

ALTER TABLE [dbo].[MF_TransacaoGado] CHECK CONSTRAINT [FK_MF_TransacaoGado_MF_Pecuarista]
GO

ALTER TABLE [dbo].[MF_TransacaoGado]  WITH CHECK ADD CONSTRAINT [FK_MF_TransacaoGado_MF_CompraGado] FOREIGN KEY([Seql_IdCompraGado])
REFERENCES [dbo].[MF_CompraGado] ([Id])
GO

ALTER TABLE [dbo].[MF_TransacaoGado] CHECK CONSTRAINT [FK_MF_TransacaoGado_MF_CompraGado]
GO

ALTER TABLE [dbo].[MF_TransacaoGado]  WITH CHECK ADD CONSTRAINT [FK_MF_TransacaoGado_MF_Animal] FOREIGN KEY([Seql_IdAnimal])
REFERENCES [dbo].[MF_Animal] ([Id])
GO

ALTER TABLE [dbo].[MF_TransacaoGado] CHECK CONSTRAINT [FK_MF_TransacaoGado_MF_Animal]
GO



