use BancoTESTE

GO

IF EXISTS( SELECT TOP 1 1 FROM  sys.objects WHERE object_id = object_id ('MFSP_CompraGado_Del') AND type = 'p')
DROP PROCEDURE [dbo].[MFSP_CompraGado_Del]

GO

CREATE PROCEDURE [dbo].[MFSP_CompraGado_Del] 

	@Id	int	= null,
	@Id_CompraGado int = null
	
	

AS
BEGIN

SELECT @Id_CompraGado = Seql_IdCompraGado 
FROM MF_TransacaoGado
WHERE Seql_Id = @Id
	
DELETE FROM MF_CompraGadoIem
		WHERE IdCompraGado = @Id_CompraGado

DELETE FROM MF_TransacaoGado
WHERE Seql_Id = @Id
	
DELETE FROM MF_CompraGado
WHERE ID = @Id_CompraGado

	 

END		
