use BancoTESTE

GO

IF EXISTS( SELECT TOP 1 1 FROM  sys.objects WHERE object_id = object_id ('MFSP_CompraGado_Upd') AND type = 'p')
DROP PROCEDURE [dbo].[MFSP_CompraGado_Upd]

GO

CREATE PROCEDURE [dbo].[MFSP_CompraGado_Upd] 

	@Nom_Pecuarista		varchar(255)	= null,
	@Descricao			varchar(255)	= null,
	@Dat_Entrega		datetime		= null,
	@Ind_Quantidade		int				= null,
	@Id					int				= null,
	@Id_Animal			int				= null
	
	

AS
BEGIN

 SELECT @Id = id 
 FROM MF_Pecuarista
 WHERE Nome = @Nom_Pecuarista

 SELECT @id_animal = id 
 FROM MF_Animal
 WHERE Descricao = @Descricao


UPDATE cg
SET DataEntrega = @Dat_Entrega
FROM MF_CompraGado cg
INNER JOIN MF_TransacaoGado tf
	ON tf.Seql_IdCompraGado = cg.Id
WHERE cg.IdPecuarista = @Id

UPDATE  cgi
SET Quantidade = @Ind_Quantidade,
	IdAnimal = @Id_animal
FROM MF_CompraGadoIem cgi
INNER JOIN MF_CompraGado cg
	ON cg.Id = cgi.IdCompraGado
INNER JOIN MF_TransacaoGado tf
	ON tf.Seql_IdCompraGado = cg.Id
WHERE cg.IdPecuarista = @Id

UPDATE	tg
	SET Dat_Entrega = cg.DataEntrega,
		Seql_IdAnimal = @Id_animal,
		Ind_Quantidade = @Ind_Quantidade,
		Vlr_CompraTotal = @Ind_Quantidade * an.Preco
FROM MF_TransacaoGado tg
INNER JOIN MF_CompraGado cg
	ON cg.Id = tg.Seql_IdCompraGado
INNER JOIN MF_CompraGadoIem cgi
	ON cgi.IdCompraGado = cg.Id
INNER JOIN MF_Animal an 
	ON an.Id = cgi.IdAnimal
WHERE tg.Seql_IdPecuarista = @Id
AND tg.Seql_IdAnimal = @Id_Animal


END		
