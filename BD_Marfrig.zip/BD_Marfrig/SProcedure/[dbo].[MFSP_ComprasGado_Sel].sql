use BancoTESTE

GO

IF EXISTS( SELECT TOP 1 1 FROM  sys.objects WHERE object_id = object_id ('MFSP_CompraGado_Sel') AND type = 'p')
DROP PROCEDURE [dbo].[MFSP_CompraGado_Sel]

GO

CREATE PROCEDURE [dbo].[MFSP_CompraGado_Sel] 

	@id int				= null,
	@nome varchar(255)	= null,
	@data datetime		= null

AS
BEGIN
	IF @data IS NOT NULL
	BEGIN
		SELECT	tg.Seql_Id, 
				pe.Nome,
				tg.Dat_Entrega,
				tg.Ind_Quantidade,
				tg.Vlr_CompraTotal
		FROM	[MF_TransacaoGado] tg
		INNER JOIN MF_Pecuarista pe 
			ON pe.Id = tg.seql_IdPecuarista
		WHERE tg.Dat_Entrega = @data
	END	
	ELSE 
	BEGIN 
		SELECT	tg.Seql_Id, 
				pe.Nome,
				tg.Dat_Entrega,
				tg.Ind_Quantidade,
				tg.Vlr_Compratotal
		FROM	[MF_TransacaoGado] tg
		INNER JOIN MF_Pecuarista pe 
			ON pe.Id = tg.seql_IdPecuarista
		WHERE (tg.Seql_Id = coalesce(@id , pe.id ) OR @id is null )
		OR	  (pe.Nome LIKE '%' + @nome + '%')
	END
END		
