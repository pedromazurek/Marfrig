use BancoTESTE

GO

IF EXISTS( SELECT TOP 1 1 FROM  sys.objects WHERE object_id = object_id ('MFSP_CompraGado_Ins') AND type = 'p')
DROP PROCEDURE [dbo].[MFSP_CompraGado_Ins]

GO

CREATE PROCEDURE [dbo].[MFSP_CompraGado_Ins] 

	@Nom_Pecuarista		varchar(255)	= null,
	@Descricao			varchar(255)	= null,
	@Dat_Entrega		datetime		= null,
	@Ind_Quantidade		int				= null,
	@Id					int				= null,
	@Id_Animal			int				= null
	

AS
BEGIN

 SELECT @Id = id 
 FROM MF_Pecuarista
 WHERE Nome = @Nom_Pecuarista

 SELECT @id_animal = id 
 FROM MF_Animal
 WHERE Descricao = @Descricao


IF EXISTS(SELECT TOP 1 1 FROM MF_TransacaoGado
				WHERE Seql_IdPecuarista = @id 
				AND Seql_IdAnimal = @Id_Animal)
BEGIN 

	UPDATE  cgi
	SET Quantidade = Quantidade + @Ind_Quantidade
	FROM MF_CompraGadoIem cgi
	INNER JOIN MF_CompraGado cg
		ON cg.Id = cgi.IdCompraGado
	INNER JOIN MF_TransacaoGado tf
		ON tf.Seql_IdCompraGado = cg.Id
	WHERE cg.IdPecuarista = @Id

	UPDATE	tf
		SET 
			Ind_Quantidade = Ind_Quantidade + @Ind_Quantidade,
			Vlr_CompraTotal = (Ind_Quantidade + @Ind_Quantidade) * an.Preco
	FROM MF_TransacaoGado tf
	INNER JOIN MF_CompraGado cg
		ON cg.Id = tf.Seql_IdCompraGado
	INNER JOIN MF_CompraGadoIem cgi
		ON cgi.IdCompraGado = cg.Id
	INNER JOIN MF_Animal an 
		ON an.Id = cgi.IdAnimal
	WHERE tf.Seql_IdPecuarista = @Id
	
END
ELSE
BEGIN

	INSERT INTO [dbo].[MF_CompraGado] values (@Id, @Dat_Entrega)

	INSERT INTO MF_CompraGadoIem
		SELECT	MAX(cg.Id),
				@id_animal,
				@Ind_Quantidade
		FROM MF_CompraGado cg
		WHERE cg.IdPecuarista = @Id

	INSERT INTO [dbo].[MF_TransacaoGado]
		SELECT
				  @Id
				 ,MAX(cg.Id)
				 ,@Dat_Entrega
				 ,an.Id
				 ,@Ind_Quantidade
				 ,@Ind_Quantidade * an.Preco
				 ,0
				 ,GETDATE()
		FROM [dbo].[MF_Pecuarista] pe
		INNER JOIN MF_CompraGado cg
			ON cg.IdPecuarista = pe.Id
		INNER JOIN MF_CompraGadoIem cgi
			ON cgi.IdCompraGado = cg.Id
		INNER JOIN MF_Animal an
			ON an.id = @Id_Animal
		WHERE pe.Id = @Id
		GROUP BY an.Id, an.Preco
END	 
	 

END		
